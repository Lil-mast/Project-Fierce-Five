const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const Cart = require('../models/Cart');
const authMiddleware = require('../middleware/authMiddleware');

router.post('/checkout', authMiddleware, async (req, res) => {
  try {
    const cart = await Cart.findOne({ userId: req.userId });
    if (!cart || cart.products.length === 0) {
      return res.status(400).json({ error: 'Cart is empty' });
    }
    const total = cart.products.reduce((sum, item) => sum + item.quantity * item.productId.price, 0);
    const order = new Order({
      userId: req.userId,
      products: cart.products,
      total,
    });
    await order.save();
    await Cart.deleteOne({ userId: req.userId });
    res.status(201).json(order);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;